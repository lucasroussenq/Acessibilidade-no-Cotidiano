document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('theme-toggle');

    // Verifica tema salvo
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.body.classList.add(savedTheme);
        themeToggle.textContent = savedTheme === 'dark-mode' ? 'Trocar para Tema Claro' : 'Trocar para Tema Escuro';
    }

    themeToggle.addEventListener('click', () => {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        themeToggle.textContent = isDarkMode ? 'Trocar para Tema Claro' : 'Trocar para Tema Escuro';
        localStorage.setItem('theme', isDarkMode ? 'dark-mode' : '');
    });
});
